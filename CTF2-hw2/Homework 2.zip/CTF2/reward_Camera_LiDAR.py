import math

def reward_function(params):
    # Read input parameters
    all_wheels_on_track = params['all_wheels_on_track']
    distance_from_center = params['distance_from_center']
    speed = params['speed']
    heading = params['heading']
    waypoints = params['waypoints']
    closest_waypoints = params['closest_waypoints']
    track_width = params['track_width']
    is_offtrack = params['is_offtrack']
    objects_distance = params['objects_distance']  # LiDAR sensor data

    # Define the reward thresholds
    MAX_SPEED = 5.0
    MIN_SPEED = 1.0
    SPEED_THRESHOLD = 2.0
    WAYPOINTS_THRESHOLD = 0.5 * len(waypoints)

    # Initialize the reward
    reward = 1e-3

    # Check if all wheels are on the track and the car is moving at an acceptable speed
    if all_wheels_on_track and not is_offtrack and speed >= MIN_SPEED:
        reward += 1.0

        # Penalize if the car is too far from the center
        reward -= 0.5 * distance_from_center

        # Bonus for driving at a higher speed
        if speed >= MAX_SPEED:
            reward += 1.0
        elif speed > SPEED_THRESHOLD:
            reward += 0.5

        # Check if the car is following the waypoints
        if closest_waypoints[1] == (closest_waypoints[0] + 1) % len(waypoints):
            reward += 2.0

        # Use LiDAR data to avoid obstacles
        min_distance_to_object = min(objects_distance)
        if min_distance_to_object > 0.2:  # Adjust threshold based on your scenario
            reward += 1.0
        else:
            reward -= 1.0

    # Penalize if the car is off the track
    else:
        reward -= 1.0

    return float(reward)
